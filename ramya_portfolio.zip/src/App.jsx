export default function Portfolio() {
  return (
    <div className="p-6 max-w-4xl mx-auto font-sans text-gray-800">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-blue-700">Ramya Jaligama</h1>
        <p className="text-md mt-2">Health Informatics | Clinical Data Analyst | Pharm.D</p>
        <div className="mt-4 text-sm">
          <p>Eglinton Avenue E, Toronto, Ontario</p>
          <p>(647) 684-1283 | <a className="text-blue-600 underline" href="mailto:ramya.jaligama@georgebrown.ca">ramya.jaligama@georgebrown.ca</a></p>
          <a className="text-blue-600 underline" href="https://www.linkedin.com/in/ramya-jaligama-409848226" target="_blank">LinkedIn Profile</a>
        </div>
      </header>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Career Objective</h2>
        <p className="mt-2">Seeking a challenging career in a position that promotes growth and stability. Dedicated and detail-oriented professional with a background in Health Informatics and Data Analysis aiming to optimize healthcare operations and achieve better patient outcomes.</p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Education</h2>
        <ul className="list-disc ml-5 mt-2">
          <li><strong>George Brown College (2024–2025)</strong> – Health Informatics
            <ul className="list-disc ml-5">
              <li>Coursework: CDSS, EMR/EHRs, Project Management, Business Analysis</li>
            </ul>
          </li>
          <li><strong>Pratishta Institute of Pharmaceutical Sciences (2017–2023)</strong> – Doctor of Pharmacy (Pharm-D)</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Professional Experience</h2>
        <ul className="list-disc ml-5 mt-2">
          <li><strong>Drug Safety Associate</strong> – Parexel (Aug 2023 – July 2024)</li>
          <li><strong>Clinical Data Analyst</strong> – (Dec 2022 – May 2023)</li>
          <li><strong>Clinical Pharmacist</strong> – Vijaykrishna Hospital (June 2022 – July 2023)</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Skills</h2>
        <ul className="list-disc ml-5 mt-2">
          <li>SQL, Python, Microsoft Office, ARGUS, CLINIREX, EMR/EHR Systems</li>
          <li>Data Analysis, Reporting, Patient Care Planning</li>
          <li>Communication, Time Management, Multitasking</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Certifications</h2>
        <ul className="list-disc ml-5 mt-2">
          <li>Doctor of Pharmacy</li>
          <li>Certified Pharmacovigilance Professional</li>
          <li>Certified Medical Coder (CPT, HCPCS)</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Achievements</h2>
        <ul className="list-disc ml-5 mt-2">
          <li>Poster presentation award on "Adverse Drug Reaction Monitoring"</li>
          <li>Academic Excellence with Distinction (6 Years)</li>
          <li>"Employee of the Year" at Novartis Client Project</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Extracurricular Activities</h2>
        <ul className="list-disc ml-5 mt-2">
          <li>Conducted tutorials on health education</li>
          <li>Delegate at X Indian Pharmaceutical Association Congress</li>
          <li>Organized public health awareness campaigns</li>
        </ul>
      </section>
    </div>
  );
}